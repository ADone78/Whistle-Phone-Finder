package com.whistle.phonefinder.tool.whistle

class LanguageModel(
    val id: String? = null,
    val name: String? = null,
    val flag: Int
)